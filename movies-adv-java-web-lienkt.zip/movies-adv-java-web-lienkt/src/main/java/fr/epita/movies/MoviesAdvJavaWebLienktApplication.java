package fr.epita.movies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesAdvJavaWebLienktApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesAdvJavaWebLienktApplication.class, args);
	}

}
