package fr.epita.movies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesAdvJavaWebLienktApplicationTests {

	@Test
	void contextLoads() {
	}

}
